"""Definition of all datasets"""

from .base_networks import DummyNetwork
